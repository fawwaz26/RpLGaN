<?php
// HTTP
define('HTTP_SERVER', 'http://localhost/jobportal/admin/');
define('HTTP_CATALOG', 'http://localhost/jobportal/');

// HTTPS
define('HTTPS_SERVER', 'http://localhost/jobportal/admin/');
define('HTTPS_CATALOG', 'http://localhost/jobportal/');

// DIR
define('DIR_APPLICATION', 'C:/xampp/htdocs/jobportal/admin/');
define('DIR_SYSTEM', 'C:/xampp/htdocs/jobportal/system/');
define('DIR_IMAGE', 'C:/xampp/htdocs/jobportal/image/');
define('DIR_LANGUAGE', 'C:/xampp/htdocs/jobportal/admin/language/');
define('DIR_TEMPLATE', 'C:/xampp/htdocs/jobportal/admin/view/template/');
define('DIR_CONFIG', 'C:/xampp/htdocs/jobportal/system/config/');
define('DIR_CACHE', 'C:/xampp/htdocs/jobportal/system/storage/cache/');
define('DIR_DOWNLOAD', 'C:/xampp/htdocs/jobportal/system/storage/download/');
define('DIR_LOGS', 'C:/xampp/htdocs/jobportal/system/storage/logs/');
define('DIR_MODIFICATION', 'C:/xampp/htdocs/jobportal/system/storage/modification/');
define('DIR_UPLOAD', 'C:/xampp/htdocs/jobportal/system/storage/upload/');
define('DIR_CATALOG', 'C:/xampp/htdocs/jobportal/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'pawas');
define('DB_PASSWORD', 'pawas_aja!');
define('DB_DATABASE', 'projekuy');
define('DB_PORT', '3306');
define('DB_PREFIX', 'oc_');
