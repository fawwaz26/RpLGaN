<?php
// Heading
$_['heading_title']  		= 'Apply Job List';
$_['text_employname']  		= 'Employee Name';
$_['text_jobname']  		= 'Job Name';
$_['text_jobtype']  		= 'Job Type';
$_['text_resume']  		    = 'Resume Download';
$_['text_date']  		    = 'Date';
$_['text_action']  		    = 'Action';
$_['text_successdelete']    = 'successfully Delete Your list ';
$_['text_viewprofile']      = 'Candidate View Profile';
