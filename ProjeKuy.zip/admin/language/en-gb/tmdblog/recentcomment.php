<?php
// Heading
$_['heading_title']                = 'Recent Comments';

// Column
$_['column_sr_no']  	 = 'Sr.No.';
$_['column_post']  		 = 'Post';
$_['column_author']      = 'Author';
$_['column_status']     = 'Status';
$_['column_action']     = 'Action';
