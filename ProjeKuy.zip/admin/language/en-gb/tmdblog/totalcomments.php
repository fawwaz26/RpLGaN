<?php
// Heading
$_['heading_title'] = '<b>Total Comments</b>';

// Text
$_['text_view'] = 'View more...';